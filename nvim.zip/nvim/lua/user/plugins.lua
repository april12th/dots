local fn = vim.fn

-- Automatically install packer
local install_path = fn.stdpath("data") .. "/site/pack/packer/start/packer.nvim"
if fn.empty(fn.glob(install_path)) > 0 then
	PACKER_BOOTSTRAP = fn.system({
		"git",
		"clone",
		"--depth",
		"1",
		"https://github.com/wbthomason/packer.nvim",
		install_path,
	})
	print("Installing packer close and reopen Neovim...")
	vim.cmd([[packadd packer.nvim]])
end

-- Autocommand that reloads neovim whenever you save the plugins.lua file
vim.cmd([[
  augroup packer_user_config
    autocmd!
    autocmd BufWritePost plugins.lua source <afile> | PackerSync
  augroup end
]])

-- Use a protected call so we don't error out on first use
local status_ok, packer = pcall(require, "packer")
if not status_ok then
	return
end

-- Have packer use a popup window
packer.init({
	display = {
		open_fn = function()
			return require("packer.util").float({ border = "rounded" })
		end,
	},
})

-- Install your plugins here
return packer.startup(function(use)
	-- My plugins here
	use("wbthomason/packer.nvim") -- Have packer manage itself
	use("nvim-lua/popup.nvim") -- An implementation of the Popup API from vim in Neovim
	use("windwp/nvim-autopairs") -- Autopairs, integrates with both cmp and treesitter
	use("numToStr/Comment.nvim") -- Easily comment stuff
	use("kyazdani42/nvim-web-devicons")
	use("kyazdani42/nvim-tree.lua")
	use("moll/vim-bbye")
	use("goolord/alpha-nvim")
	use("nvim-lualine/lualine.nvim")
	use("akinsho/toggleterm.nvim")
	use("ahmedkhalf/project.nvim")
	use("lewis6991/impatient.nvim")
	use("lukas-reineke/indent-blankline.nvim")
	use("antoinemadec/FixCursorHold.nvim") -- This is needed to fix lsp doc highlight
	use("karb94/neoscroll.nvim")
	use("romgrk/barbar.nvim")
	--  use {
	--    "anuvyklack/windows.nvim",
	--    requires = {
	--      "anuvyklack/middleclass",
	--      "anuvyklack/animation.nvim"
	--    },
	--    config = function()
	--      vim.o.winwidth = 10
	--      vim.o.winminwidth = 10
	--      vim.o.equalalways = false
	--      require('windows').setup({autowidth = {enable=false}})
	--    end
	--  }

	-- Colors
	use("NvChad/nvim-colorizer.lua")
	use("ziontee113/color-picker.nvim")

	-- cmd Plugins
	use({
		"folke/noice.nvim",
		requires = {
			"MunifTanjim/nui.nvim",
			"rcarriga/nvim-notify",
		},
	})

	-- Keybindings
	use("folke/which-key.nvim")

	-- cmp plugins
	use("hrsh7th/nvim-cmp") -- The completion plugin
	use("hrsh7th/cmp-buffer") -- buffer completions
	use("hrsh7th/cmp-path") -- path completions
	use("hrsh7th/cmp-cmdline") -- cmdline completions
	use("saadparwaiz1/cmp_luasnip") -- snippet completions
	use("hrsh7th/cmp-nvim-lsp")

	-- snippets
	use("L3MON4D3/LuaSnip") -- snippet engine
	use("rafamadriz/friendly-snippets") -- a bunch of snippets to use

	-- Lua Development
	use("nvim-lua/plenary.nvim") -- Useful lua functions used by lots of plugins
	use("folke/lua-dev.nvim") -- Lua development with full signature help, docs and completion

	-- LSP
	use("neovim/nvim-lspconfig") -- enable LSP
	use("williamboman/mason.nvim")
	use("williamboman/mason-lspconfig.nvim")
	use("tamago324/nlsp-settings.nvim") -- language server settings defined in json for
	use("jose-elias-alvarez/null-ls.nvim") -- for formatters and linters
	use({ "glepnir/lspsaga.nvim", commit = "97c63854c482f1f53aa1bce4bf7f15a352de13cd" })
	use("RRethy/vim-illuminate") -- highlight other uses of the word under cursor-- Nvim Navic
	use("SmiteshP/nvim-navic") -- Gps
	use("https://git.sr.ht/~whynothugo/lsp_lines.nvim") -- Diagnostics using virtual text
	use("ray-x/lsp_signature.nvim") -- Signature help
	use("simrat39/symbols-outline.nvim")
	use("simrat39/rust-tools.nvim")

	-- Telescope
	use("nvim-telescope/telescope.nvim")

	-- Treesitter
	use({
		"nvim-treesitter/nvim-treesitter",
		commit = "730efb4e58ed084150665653e6ffe780015ec29d",
		run = ":TSUpdate",
	})
	use("JoosepAlviste/nvim-ts-context-commentstring")
	use("windwp/nvim-ts-autotag")

	-- Debugging
	use("mfussenegger/nvim-dap")
	use("rcarriga/nvim-dap-ui")
	use("ravenxrz/DAPInstall.nvim")

	-- Testing
	use({
		"nvim-neotest/neotest",
		requires = {
			"nvim-neotest/neotest-python",
			"nvim-neotest/neotest-plenary",
			"nvim-neotest/neotest-vim-test",
		},
	})

	-- Git
	use("lewis6991/gitsigns.nvim")
	
	-- AI
	use({
		'archibate/nvim-gpt',
		-- optional for supporting ':Telescope nvim-gpt gpt_model/gpt_history/gpt_template' commands
		requires = { 'nvim-telescope/telescope.nvim' },
	})
	use('Exafunction/codeium.vim')

	-- Automatically set up your configuration after cloning packer.nvim
	-- Put this at the end after all plugins
	if PACKER_BOOTSTRAP then
		require("packer").sync()
	end
end)

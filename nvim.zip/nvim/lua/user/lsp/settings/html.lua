local opts = {
  filetypes = {"html", "htmldjango"},
}

return opts
